# TCC Estoque

Este projeto é uma aplicação web desenvolvida como parte do Trabalho de Conclusão de Curso (TCC) do curso de Análise e Desenvolvimento de Sistemas (ADS) no Senai-MG. A aplicação tem como objetivo facilitar o armazenamento, registro e monitoramento de produtos em estoque, incluindo dados de vencimento.

## Estrutura do Projeto

O projeto é organizado da seguinte forma:

```
tcc-estoque-html
├── public
│   ├── index.html        # Estrutura HTML principal da aplicação
│   ├── styles.css       # Estilos CSS para a interface
│   └── script.js        # Funcionalidades em JavaScript
├── package.json         # Configuração do npm
└── README.md            # Documentação do projeto
```

## Funcionalidades

- **Armazenamento de Produtos**: Permite registrar e armazenar informações sobre os produtos em estoque.
- **Monitoramento de Vencimentos**: Monitora as datas de vencimento dos produtos, alertando o usuário sobre produtos que estão próximos do vencimento.
- **Adição de Novos Produtos**: Facilita a adição de novos produtos ao sistema.

## Instruções de Configuração

1. Clone o repositório:
   ```
   git clone <URL do repositório>
   ```

2. Navegue até o diretório do projeto:
   ```
   cd tcc-estoque-html
   ```

3. Instale as dependências:
   ```
   npm install
   ```

4. Abra o arquivo `public/index.html` em um navegador para visualizar a aplicação.

## Uso

Após abrir a aplicação, você poderá:

- Adicionar novos produtos ao estoque.
- Visualizar os produtos armazenados.
- Monitorar as datas de vencimento e receber alertas.

## Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou pull requests.

## Licença

Este projeto está licenciado sob a MIT License.