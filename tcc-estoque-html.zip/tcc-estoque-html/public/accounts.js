// Controle de Estoque - TCC ADS Senai-MG
// Gerenciamento de Contas

// Sistema de Usuários
let users = JSON.parse(localStorage.getItem('users')) || [];
let currentUser = null;
let userToEdit = null;
let userToDelete = null;

// Inicializar usuários padrão se não existirem
if (users.length === 0) {
    users.push({ username: 'admin', password: '123', role: 'admin' });
    users.push({ username: 'gerente', password: '456', role: 'gerente' });
    localStorage.setItem('users', JSON.stringify(users));
}

function authenticateUser(username, password) {
    return users.find(user => user.username === username && user.password === password);
}

function createUser(username, password, role = 'user') {
    if (users.find(user => user.username === username)) {
        return false; // Usuário já existe
    }
    users.push({ username, password, role });
    localStorage.setItem('users', JSON.stringify(users));
    return true;
}

// Verificar se usuário está logado
document.addEventListener('DOMContentLoaded', function() {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        const user = JSON.parse(savedUser);
        if (user.role === 'gerente') {
            currentUser = user;
            document.getElementById('login-screen').style.display = 'none';
            document.getElementById('main-content').style.display = 'block';
            initAccountsPage();
        } else {
            alert('Acesso negado! Apenas gerentes podem acessar esta página.');
            window.location.href = 'index.html';
        }
    } else {
        // Mostrar tela de login
        document.getElementById('login-screen').style.display = 'block';
        document.getElementById('main-content').style.display = 'none';
    }

    // Login form
    const loginForm = document.getElementById('login-form');
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        const user = authenticateUser(username, password);
        if (user && (user.role === 'admin' || user.role === 'gerente')) {
            currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(user));
            document.getElementById('login-screen').style.display = 'none';
            document.getElementById('main-content').style.display = 'block';
            window.location.href = `accounts.html?user=${user.username}`;
        } else {
            alert('Acesso negado! Apenas administradores podem acessar esta página.');
        }
    });

    // Event listeners para modal
    document.getElementById('confirm-yes').addEventListener('click', function() {
        confirmDelete();
        hideConfirmModal();
    });
    document.getElementById('confirm-no').addEventListener('click', hideConfirmModal);

    // Event listener para formulário de criação de conta
    const adminCreateAccountForm = document.getElementById('admin-create-account-form');
    adminCreateAccountForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const username = document.getElementById('admin-new-username').value;
        const password = document.getElementById('admin-new-password').value;
        const confirmPassword = document.getElementById('admin-confirm-password').value;
        const newRole = document.getElementById('admin-new-role').value;

        // Verificar se está tentando criar um gerente
        if (newRole === 'gerente' && currentUser.role !== 'gerente') {
            alert('Apenas gerentes podem criar contas de gerente!');
            return;
        }

        if (password !== confirmPassword) {
            alert('As senhas não coincidem!');
            return;
        }

        if (createUser(username, password, newRole)) {
            alert('Conta criada com sucesso!');
            adminCreateAccountForm.reset();
            renderUsers();
        } else {
            alert('Usuário já existe!');
        }
    });

    // Event listeners para modal de edição de usuário
    const editUserForm = document.getElementById('edit-user-form');
    editUserForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const newUsername = document.getElementById('edit-username').value.trim();
        const newPassword = document.getElementById('edit-password').value;
        const newRole = document.getElementById('edit-role').value;

        if (!newUsername) {
            alert('O nome de usuário não pode estar vazio!');
            return;
        }

        const userIndex = users.findIndex(u => u.username === userToEdit);
        if (userIndex === -1) return;

        // Verificar se o novo username já existe (exceto o próprio)
        if (users.some(u => u.username === newUsername && u.username !== userToEdit)) {
            alert('Este nome de usuário já existe!');
            return;
        }

        users[userIndex].username = newUsername;
        if (newPassword) {
            users[userIndex].password = newPassword;
        }
        users[userIndex].role = newRole;

        localStorage.setItem('users', JSON.stringify(users));

        // Se editou o próprio usuário, atualizar currentUser
        if (userToEdit === currentUser.username) {
            currentUser = users[userIndex];
        }

        alert('Usuário atualizado com sucesso!');
        hideEditUserModal();
        renderUsers();
    });

    document.getElementById('cancel-edit-user').addEventListener('click', hideEditUserModal);

    // Event listener para logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('currentUser');
            window.location.href = 'index.html';
        });
    }
});

function initAccountsPage() {
    renderUsers();
}

function renderUsers() {
    const usersList = document.getElementById('users-list');
    if (!usersList) return;

    usersList.innerHTML = '';

    users.forEach(user => {
        const userCard = document.createElement('div');
        userCard.className = 'user-card';
        userCard.innerHTML = `
            <div class="user-info">
                <div class="user-name">${user.username}</div>
                <div class="user-role">Papel: ${user.role}</div>
                <div class="user-actions">
                    <button class="btn btn-warning edit-user-btn" data-username="${user.username}">Editar</button>
                    <button class="btn btn-danger delete-user-btn" data-username="${user.username}">Excluir</button>
                </div>
            </div>
        `;

        // Adicionar event listeners
        const editBtn = userCard.querySelector('.edit-user-btn');
        const deleteBtn = userCard.querySelector('.delete-user-btn');

        editBtn.addEventListener('click', () => editUser(user.username));
        deleteBtn.addEventListener('click', () => deleteUser(user.username));

        usersList.appendChild(userCard);
    });
}

function editUser(username) {
    const user = users.find(u => u.username === username);
    if (!user) return;

    userToEdit = username;
    document.getElementById('edit-username').value = user.username;
    document.getElementById('edit-password').value = '';
    document.getElementById('edit-role').value = user.role;

    showEditUserModal();
}

function deleteUser(username) {
    if (username === currentUser.username) {
        alert('Você não pode excluir sua própria conta!');
        return;
    }

    userToDelete = username;
    showConfirmModal('Tem certeza que deseja excluir este usuário?');
}

function showEditUserModal() {
    const modal = document.getElementById('edit-user-modal');
    modal.classList.add('show');
}

function hideEditUserModal() {
    const modal = document.getElementById('edit-user-modal');
    modal.classList.remove('show');
    document.getElementById('edit-user-form').reset();
    userToEdit = null;
}

function showConfirmModal(message = 'Tem certeza que deseja excluir este produto?') {
    const modal = document.getElementById('confirm-modal');
    modal.querySelector('p').textContent = message;
    modal.classList.add('show');
}

function hideConfirmModal() {
    const modal = document.getElementById('confirm-modal');
    modal.classList.remove('show');
    userToDelete = null;
}

function confirmDelete() {
    if (userToDelete !== null) {
        users = users.filter(u => u.username !== userToDelete);
        localStorage.setItem('users', JSON.stringify(users));
        renderUsers();
        userToDelete = null;
    }
    hideConfirmModal();
}