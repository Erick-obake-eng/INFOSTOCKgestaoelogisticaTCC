// Controle de Estoque - TCC ADS Senai-MG
// Iniciado em 15-03-2026

// Sistema de Usuários
let users = JSON.parse(localStorage.getItem('users')) || [];
let currentUser = null;

// Inicializar usuário admin se não existir
if (users.length === 0) {
    users.push({ username: 'admin', password: '123', role: 'admin' });
    localStorage.setItem('users', JSON.stringify(users));
}

function authenticateUser(username, password) {
    return users.find(user => user.username === username && user.password === password);
}

function createUser(username, password, role = 'user') {
    if (users.find(user => user.username === username)) {
        return false; // Usuário já existe
    }
    users.push({ username, password, role });
    localStorage.setItem('users', JSON.stringify(users));
    return true;
}

// Função de Login
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se usuário está logado
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
        initApp(currentUser);
    } else {
        // Mostrar tela de login
        document.getElementById('login-screen').style.display = 'block';
        document.getElementById('main-content').style.display = 'none';
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            const user = authenticateUser(username, password);
            if (user) {
                currentUser = user;
                localStorage.setItem('currentUser', JSON.stringify(user));
                document.getElementById('login-screen').style.display = 'none';
                document.getElementById('main-content').style.display = 'block';
                // Inicializar o app após login
                initApp(user);
            } else {
                alert('Usuário ou senha incorretos!');
            }
        });

        // Botão criar conta
        document.getElementById('create-account-btn').addEventListener('click', function() {
            if (!currentUser || currentUser.role !== 'admin') {
                alert('Apenas administradores podem criar contas!');
                return;
            }
            showCreateAccountModal();
        });
    } else {
        // Se não há tela de login, inicializar diretamente
        initApp();
    }

    // Modal de criação de conta
    const createAccountForm = document.getElementById('create-account-form');
    if (createAccountForm) {
        createAccountForm.addEventListener('submit', function(e) {
            e.preventDefault();

            if (!currentUser || currentUser.role !== 'admin') {
                alert('Apenas administradores podem criar contas!');
                return;
            }

            const username = document.getElementById('new-username').value;
            const password = document.getElementById('new-password').value;
            const confirmPassword = document.getElementById('confirm-password').value;

            if (password !== confirmPassword) {
                alert('As senhas não coincidem!');
                return;
            }

            if (createUser(username, password)) {
                alert('Conta criada com sucesso! Faça o login.');
                hideCreateAccountModal();
            } else {
                alert('Usuário já existe!');
            }
        });

        document.getElementById('cancel-create').addEventListener('click', hideCreateAccountModal);
    }
});

function showCreateAccountModal() {
    const modal = document.getElementById('create-account-modal');
    modal.classList.add('show');
}

function hideCreateAccountModal() {
    const modal = document.getElementById('create-account-modal');
    modal.classList.remove('show');
    document.getElementById('create-account-form').reset();
}

function initApp(user = null) {
    currentUser = user;
    // Código de inicialização do app
    renderProducts();
    renderExpiringProducts();

    // Verificar se o usuário é admin para mostrar botão de criar conta e nav de gerenciar contas
    const createAccountBtn = document.getElementById('create-account-btn');
    if (createAccountBtn) {
        if (currentUser && currentUser.role === 'admin') {
            createAccountBtn.style.display = 'inline-block';
        } else {
            createAccountBtn.style.display = 'none';
        }
    }

    const manageAccountsNav = document.getElementById('manage-accounts-nav');
    if (manageAccountsNav) {
        if (currentUser && currentUser.role === 'admin') {
            manageAccountsNav.style.display = 'block';
            const link = manageAccountsNav.querySelector('a');
            link.href = `accounts.html?user=${currentUser.username}`;
        } else {
            manageAccountsNav.style.display = 'none';
        }
    }

    // Event listeners para o formulário de adicionar produto
    document.getElementById('add-product-form').addEventListener('submit', addProduct);

    // Event listeners para busca
    document.getElementById('search-btn').addEventListener('click', searchProducts);
    document.getElementById('search-input').addEventListener('input', searchProducts);

    // Event listeners para modal
    document.getElementById('confirm-yes').addEventListener('click', function() {
        confirmDelete();
        hideConfirmModal();
    });
    document.getElementById('confirm-no').addEventListener('click', hideConfirmModal);

    // Event listener para logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('currentUser');
            location.reload();
        });
    }
}

let products = JSON.parse(localStorage.getItem('products')) || [];
let productToDelete = null;
let userToEdit = null;
let userToDelete = null;

function editProduct(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;

    // Preencher o formulário com os dados do produto
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-quantity').value = product.quantity;
    document.getElementById('product-manufacture').value = product.manufactureDate;
    document.getElementById('product-expiration').value = product.expirationDate;
    document.getElementById('product-category').value = product.category;

    // Remover o produto antigo
    deleteProduct(id, false);

    // Scroll para o formulário
    document.getElementById('add-product').scrollIntoView({ behavior: 'smooth' });
}

function deleteProduct(id, confirmDelete = true) {
    if (confirmDelete) {
        productToDelete = id;
        showConfirmModal();
        return;
    }

    // Se não precisa confirmar, deleta diretamente
    products = products.filter(p => p.id !== id);
    saveProducts();
    renderProducts();
    renderExpiringProducts();
}

function showConfirmModal() {
    const modal = document.getElementById('confirm-modal');
    modal.classList.add('show');
}

function hideConfirmModal() {
    const modal = document.getElementById('confirm-modal');
    modal.classList.remove('show');
    productToDelete = null;
    userToDelete = null;
}

function confirmDelete() {
    if (productToDelete !== null) {
        products = products.filter(p => p.id !== productToDelete);
        saveProducts();
        renderProducts();
        renderExpiringProducts();
        productToDelete = null;
    } else if (userToDelete !== null) {
        users = users.filter(u => u.username !== userToDelete);
        localStorage.setItem('users', JSON.stringify(users));
        renderUsers();
        userToDelete = null;
    }
    hideConfirmModal();
}

function cancelDelete() {
    productToDelete = null;
    userToDelete = null;
    hideConfirmModal();
}

function saveProducts() {
    localStorage.setItem('products', JSON.stringify(products));
}

function getExpirationStatus(expirationDate) {
    const today = new Date();
    const expDate = new Date(expirationDate);
    const daysUntilExpiration = Math.ceil((expDate - today) / (1000 * 60 * 60 * 24));

    if (expDate < today) return 'expired';
    if (daysUntilExpiration <= 7) return 'expiring';
    return 'normal';
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';

    const status = getExpirationStatus(product.expirationDate);
    if (status === 'expiring') card.classList.add('expiring');
    if (status === 'expired') card.classList.add('expired');

    card.innerHTML = `
        <div class="product-info">
            <div class="product-name">${product.name}</div>
            <div class="product-details">
                Quantidade: ${product.quantity}<br>
                Categoria: ${product.category}<br>
                Fabricação: ${formatDate(product.manufactureDate)}<br>
                Vencimento: ${formatDate(product.expirationDate)}
            </div>
            <div class="product-actions">
                <button class="btn btn-warning edit-btn" data-id="${product.id}">Editar</button>
                <button class="btn btn-danger delete-btn" data-id="${product.id}">Excluir</button>
            </div>
        </div>
    `;

    // Adicionar event listeners aos botões
    const editBtn = card.querySelector('.edit-btn');
    const deleteBtn = card.querySelector('.delete-btn');
    editBtn.addEventListener('click', () => editProduct(product.id));
    deleteBtn.addEventListener('click', () => deleteProduct(product.id));

    return card;
}

function renderProducts(filteredProducts = products) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    if (filteredProducts.length === 0) {
        productList.innerHTML = '<p>Nenhum produto encontrado.</p>';
        return;
    }

    filteredProducts.forEach(product => {
        const card = createProductCard(product);
        productList.appendChild(card);
    });
}

function renderExpiringProducts() {
    const expiringProducts = document.getElementById('expiring-products');
    expiringProducts.innerHTML = '';

    const today = new Date();
    const warningDays = 7; // Alertar 7 dias antes do vencimento

    const expiring = products.filter(product => {
        const expDate = new Date(product.expirationDate);
        const daysUntilExpiration = Math.ceil((expDate - today) / (1000 * 60 * 60 * 24));
        return daysUntilExpiration <= warningDays && daysUntilExpiration >= 0;
    });

    const expired = products.filter(product => {
        const expDate = new Date(product.expirationDate);
        return expDate < today;
    });

    [...expired, ...expiring].forEach(product => {
        const card = createProductCard(product);
        expiringProducts.appendChild(card);
    });

    if (expired.length + expiring.length === 0) {
        expiringProducts.innerHTML = '<p>Nenhum produto próximo ao vencimento.</p>';
    }
}

function renderUsers() {
    // Função movida para accounts.js
}

function editUser(username) {
    // Função movida para accounts.js
}

function deleteUser(username) {
    // Função movida para accounts.js
}

function showEditUserModal() {
    // Função movida para accounts.js
}

function hideEditUserModal() {
    // Função movida para accounts.js
}

function showConfirmModal(message = 'Tem certeza que deseja excluir este produto?') {
    const modal = document.getElementById('confirm-modal');
    modal.querySelector('p').textContent = message;
    modal.classList.add('show');
}

function searchProducts() {
    const searchInput = document.getElementById('search-input');
    const query = searchInput.value.toLowerCase();
    const filtered = products.filter(product =>
        product.name.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
    );
    renderProducts(filtered);
}

function addProduct(e) {
    e.preventDefault();

    const name = document.getElementById('product-name').value.trim();
    const quantity = parseInt(document.getElementById('product-quantity').value);
    const manufactureDate = document.getElementById('product-manufacture').value;
    const expirationDate = document.getElementById('product-expiration').value;
    const category = document.getElementById('product-category').value;

    // Validação básica
    if (!name || !quantity || !manufactureDate || !expirationDate || !category) {
        alert('Por favor, preencha todos os campos.');
        return;
    }

    if (quantity <= 0) {
        alert('A quantidade deve ser maior que zero.');
        return;
    }

    const product = {
        id: Date.now(),
        name,
        quantity,
        manufactureDate,
        expirationDate,
        category
    };

    products.push(product);
    saveProducts();
    renderProducts();
    renderExpiringProducts();
    document.getElementById('add-product-form').reset();
}

document.addEventListener('DOMContentLoaded', function() {
    const productForm = document.getElementById('add-product-form');
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const confirmYesBtn = document.getElementById('confirm-yes');
    const confirmNoBtn = document.getElementById('confirm-no');

    // Event listeners
    productForm.addEventListener('submit', addProduct);
    searchBtn.addEventListener('click', searchProducts);
    searchInput.addEventListener('input', searchProducts);
    confirmYesBtn.addEventListener('click', confirmDelete);
    confirmNoBtn.addEventListener('click', cancelDelete);

    // Initial render
    renderProducts();
    renderExpiringProducts();

    // Verificar vencimentos diariamente
    setInterval(() => {
        renderExpiringProducts();
    }, 86400000); // 24 horas
});
